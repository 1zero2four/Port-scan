# ScanPort
## 在线端口扫描工具

- PHP+Bootstrap
- 程序比较简单，有两个文件

## 文件结构

- index.php 入口，输入要扫描的IP地址
- ScanPort.php 端口扫描并输出结果

## 界面 
![](https://github.com/catkint/ScanPort/blob/master/image/input.jpg)
![](https://github.com/catkint/ScanPort/blob/master/image/output.jpg)
